<template>
  <v-container fluid>
    <v-layout row wrap>
      <v-flex v-for="market in live_markets" :key="market" class='mx-1 my-1 elevation-1'>
        <v-card>
          <div class='market-card-title title'>
              <span>{{market.toUpperCase()}}</span>
          </div>
          <v-card-text>
            <v-layout row  justify-space-around>
              <v-card flat class='mx-2'>
                <div class='subheading text-xs-left mb-2'>Order Book</div>
                <order-book :market='market' :book='market_books[market] || {[market]: {"ask": {}, "bid": {}}}'
                            :orders='market_orders[market] || {[market]: {"ask": {}, "bid": {}}}'
                            :rate='rate[market.split("_")[0]] || 0'/>
              </v-card>
              <v-card flat class='mx-2'>
                <div v-if='bitMex(market)'>
                  <div class='subheading text-xs-center mb-2'>{{positions[market.toLowerCase()] | position}}</div>
                  <signal-chart v-if='bitMex(market)' :market='market' :signals='signal[market]'/>
                </div>
                <div v-if='!bitMex(market)'>
                  <div class='subheading text-xs-left mb-2'>Our Orders</div>
                  <my-orders v-if='!bitMex(market)' :book='market_orders[market]'/>
                </div>
              </v-card>
            </v-layout>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>

<script>
  import OrderBook from './table/OrderBook'
  import MyOrders from './table/MyOrders'
  import {mapState} from 'vuex';
  import SignalChart from './table/SignalChart';

  export default {
    name: "market-overview",
    data: function () {
      return {}
    },
    computed: {
      ...mapState(['market_books', 'market_orders', 'live_markets', 'rate', 'signal' , 'positions']),
    },
    components: {
      SignalChart, OrderBook, MyOrders
    },
    methods: {
      bitMex(input) {
        const market = input.toLowerCase();
        return market === "usd_btc" || market === "jpy_btc";
      }
    },
    filters: {
      position (input) {
        if (input === 0){
          return "Current Postion: None"
        } else if (input > 0){
          return "Current Position: " + input + " Long"
        } else {
          return "Current Position: " + input + " Short"
        }
      }
    }
  }
</script>

<style lang='scss' scoped>
  .market-card-title {
    padding: 12px 16px 8px 25px !important;
  }


</style>
