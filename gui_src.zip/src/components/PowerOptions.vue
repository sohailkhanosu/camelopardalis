<template>
  <v-menu
    v-model="menu"
    left
    offset-y
    transition='scale-transition'
    origin='top right'
  >
    <v-btn icon small slot="activator" >
      <v-icon :color='syncing ? "error" : "secondary lighten-2"'>settings_power</v-icon>
    </v-btn>      <v-list>
    <v-list-tile @click='batchOffRequest' :disabled='syncing'>
      <v-list-tile-title>All Bots</v-list-tile-title>
      <v-list-tile-content />
      <v-list-tile-action><v-icon color='error'>pause_circle_outline</v-icon></v-list-tile-action>
    </v-list-tile>
    <v-list-tile @click='batchOnRequest' :disabled='syncing'>
      <v-list-tile-title>All Bots</v-list-tile-title>
      <v-list-tile-content />
      <v-list-tile-action><v-icon color='success'>play_circle_outline</v-icon></v-list-tile-action>
    </v-list-tile>
  </v-list>

  </v-menu>
</template>

<script>
  import {mapState, mapGetters} from 'vuex'
  import api from '../api'

  export default {
    name: "power-options",
    data: function () {
      return {
        menu: false,
      }
    },
    methods: {
      batchOffRequest(){
        this._batchRequest(1, 2);
      },
      batchOnRequest() {
        this._batchRequest(2, 1);
      },
      _batchRequest(current, command) {
        Object.keys(this.bot_state).forEach(ex => {
          if ((this.bot_state[ex].req === current) && (this.bot_state[ex].bot === current)){
            const payload = {ex: ex, req: command};
            this.$store.commit('power_request',payload);
            api.post.power(payload);
          }
        });
      }
    },
    computed: {
      ...mapState(['bot_state', 'exchangeConfigDict']),
      ...mapGetters(['state_syncing']),
      syncing: function () {
        return Object.keys(this.state_syncing).some(x => this.state_syncing[x]);
      }
    },
    mounted: function() {
    },
    components: {

    }
  }
</script>

<style lang='scss' scoped>

</style>
