<template>
  <v-container>
  <v-layout row>
    <table-card title='Global Dynamic Balance Strategy'>
      <edit-table slot='table' :config='config' table-id='global_target_balance' :rows='global_target_balance' :key-field='["cur", "cur"]'/>
    </table-card>
  </v-layout>
  </v-container>
</template>

<script>
  import {mapState} from 'vuex'
  import EditTable from './table/EditTable';
  import TableCard from './table/TableCard';
  import OrderBook from './table/OrderBook'

  export default {
    name: "currency",
    data: function () {
      return {
        config: [
          {title: 'Cur', field: 'cur', style: 'cell-text', size: 6, validator: this.currencyValidator, disabled: true},
          {title: 'Target', field: 'target', style: 'cell-int', size: 6, validator: x => x > 0, disabled: false},
          {title: 'Buffer', field: 'buffer', style: 'cell-int', size: 6, validator: x => x > 0, disabled: false},
          {title: 'Thresh', field: 'threshold', style: 'cell-int', size: 6, validator: x => x > 0, disabled: false},
          {title: 'Active', field: 'active', style: 'cell-select-bool', size: [true, false], validator: x => true, disabled: false},
        ]
      }
    },
    computed: {
      ...mapState(['global_target_balance', 'currencySet'])
    },
    components: {
      OrderBook,
      EditTable,
      TableCard
    },
    methods: {
      currencyValidator(value) {
        return this.currencySet.has(value);
      },
    }

  }
</script>

<style lang='scss' scoped>
  .views-orderbook {
    font-size: 1.3rem;
    font-weight: bold;
    .views-orderbook-row {
      padding: 0;
      margin: 0;
    }
  }
</style>
