<template>
  <v-container>
    <v-layout row>
      <table-card title='Bot Supervisor' menu-state='config'>
        <table-options slot='menu'/>
        <action-table slot='table'/>
      </table-card>
    </v-layout>
  </v-container>
</template>

<script>
  import ActionTable from './table/ActionTable';
  import TableCard from './table/TableCard';
  import TableOptions from './table/TableOptions'

  export default {
    name: "supervisor",
    data: function () {
      return {
        config: 'hello'
      }
    },
    computed: {
    },
    components: {
      ActionTable, TableCard, TableOptions
    },
    methods: {
      currencyValidator(value) {
        return this.currencySet.has(value);
      },
    }
  }
</script>

<style scoped>

</style>
