<template>
  <tr>
    <component v-for='cell in config'
               :key='cell.field'
               :is='cell.style'
               :size='cell.size'
               :validator='cell.validator'
               :field='cell.field'
               :editDisabled='false'
               default=''
               @edit='logEdit'
               @enterEdit='logEdit'
    >
    </component>
    <td>
      <v-btn class='v-btn-no-margin' flat icon small  @click='submitNew'><v-icon small dark>done</v-icon></v-btn>
      <v-btn class='v-btn-no-margin' flat icon small  @click='submitCancel'><v-icon small dark>remove</v-icon></v-btn>
    </td>
  </tr>
</template>

<script>
  // TODO add id= for each cell
  import CellText from './CellText'
  import CellInt from './CellInt'
  import CellFloat from './CellFloat'
  import CellSelectBool from './CellSelectBool'
  import CellSelectNumber from './CellSelectNumber'
  import CellSelectText from './CellSelectText'

  export default {
    name: "table-new-row",
    data: function() {
      let editFields = {};
      this.config.forEach(c => {
        editFields[c.field] = '';
      });
      return {
        editFields: editFields,
      }
    },
    props: {
      config: {type: Array, required: true}
    },

    computed: {},
    methods: {
      logEdit: function (cell) {
        this.editFields[cell.field] = cell.value;
      },
      submitNew(){
        let payload =  Object.assign({}, this.editFields);
        this.$emit('newRequest', payload);
      },
      submitCancel() {
        this.$emit('cancelAddRequest', false);
      },
      enterEdit() {
        this.editFields[cell.field] = cell.value;
      }
    },
    components: {
      CellText, CellInt, CellFloat, CellSelectBool, CellSelectNumber, CellSelectText
    },
  }
</script>

<style scoped>
  .v-btn-no-margin {
    margin: 0 !important;
  }
  #app.table.table tbody td, table.table tbody th {
    min-height: 20px !important;
    height: 20px !important;
  }
</style>
