<template>
  <td ><input
    @input="$v.value.$touch"
    @focus='value = ""'
    @keyup.enter='editEventEnter'
    @blur='editEvent'
    @tab='editEvent'
    :disabled='editDisabled'
    v-model='value'
    v-bind:class="{error: $v.value.$error, valid: $v.value.$dirty && !$v.value.$invalid}"
    :size='size'
  ></td>
</template>

<script>
  import {required, numeric, minValue} from 'vuelidate/lib/validators'

  export default {
    name: "cell-int",
    data: function () {
      return {
        value: this.default,
      }
    },
    props: {
      default: {required:true},
      validator: {type: Function, required: true},
      size: {type: Number, required: false},
      field: {type: String, required: true},
      editDisabled: {type: Boolean, required: true}
    },

    watch: {
      default: function (updated, old) {
        this.value = updated;
      }
    },

    validations () {
      function validatorFunction(input){
        return this.validator(input)
      }
      return {
        value: {
          required,
          numeric,
          minValue: minValue(0),
          validatorFunction
        }
      }
    },
    methods: {
      editEvent: function (event){
        this.$v.value.$touch();
        this.value = this.validator(parseInt(this.value)) ? parseInt(this.value) : this.default;
        this.$emit('edit', {value: this.value, default: this.default, field: this.field});
      },
      editEventEnter: function (event){
        this.editEvent(event);
        this.$emit('enterEdit');
      },
    }
  }
</script>

<style scoped>
  input {}
  .error:focus {
    outline-color: #F99;
  }
  .valid:focus {
    outline-color: #8E8;
  }
</style>
