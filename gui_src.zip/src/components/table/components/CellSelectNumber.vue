<template>
  <td>
    <select v-model.number="value" @change='editEvent'>
      <option v-for='o in size'>{{o}}</option>
    </select>
  </td>
</template>

<script>
  export default {
    name: "cell-select-number",
    data: function () {
      return {
        value: this.default,
      }
    },
    props: {
      default: {required:true},
      validator: {type: Function, required: false},
      size: {required: true},
      field: {type: String, required: true},
      editDisabled: {type: Boolean, required: false}
    },
    watch: {
      default: function (updated, old) {
        this.value = updated;
      }
    },
    methods: {
      editEvent: function (event){
        this.$emit('edit', {value: this.value, default: this.default, field: this.field});
      }
    }
  }
</script>

<style scoped>
</style>
