<template>
  <tr>
    <th v-for="cell in columns"
        @click="sortEmit(cell.field)"
        :key='cell.field'
    >{{cell.title}}
    </th>
    <th>
      <v-btn flat icon @click='addButton'><v-icon small dark>add</v-icon></v-btn>
    </th>
  </tr>
</template>

<script>
  export default {
    data: function () {
      return {}
    },
    props: {
      columns: {type: Array, required: true},
    },
    methods: {
      sortEmit: function (cell) {
        this.$emit('sortRequest', cell);
      },
      addButton: function() {
        this.$emit('addRequest', true);
      }
    }
  }
</script>

<style scoped>
  th.th-icon {
    padding: 0px !important;
  }
</style>
