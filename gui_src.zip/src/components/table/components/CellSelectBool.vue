<template>
  <td>
    <select v-model="value" @change='editEvent'>
      <option :value='true'>{{true}}</option>
      <option :value='false'>{{false}}</option>
    </select>
  </td>
</template>

<script>
  export default {
    name: "cell-select-bool",
    data: function () {
      return {
        value: this.default,
      }
    },
    props: {
      default: {required:true},
      validator: {type: Function, required: false},
      size: {required: true},
      field: {type: String, required: true},
      editDisabled: {type: Boolean, required: false}
    },
    watch: {
      default: function (updated, old) {
        this.value = updated;
      }
    },
    methods: {
      editEvent: function (event){
        this.$emit('edit', {value: this.value, default: this.default, field: this.field});
      }
    }
  }
</script>

<style scoped>
</style>
