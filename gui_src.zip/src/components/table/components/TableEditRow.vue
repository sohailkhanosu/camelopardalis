<template>
  <tr>
    <component v-for='cell in config'
               :key='cell.field'
               :is='cell.style'
               :default='row[cell.field]'
               :size='cell.size'
               :validator='cell.validator'
               :field='cell.field'
               :editDisabled='cell.disabled'
               @edit='logEdit'
               @enterEdit='enterEdit'
    >
    </component>
    <td>
      <v-btn :id='btnId' v-show='!editDisabled' :disabled='editDisabled' class='v-btn-no-margin' flat icon small
             @click='submitEdit'>
        <v-icon small dark>done</v-icon>
      </v-btn>
      <v-btn class='v-btn-no-margin' flat icon small @click='submitDelete'>
        <v-icon small dark>delete</v-icon>
      </v-btn>
    </td>
  </tr>
</template>

<script>
  import uuidv4 from 'uuid'
  import CellText from './CellText'
  import CellInt from './CellInt'
  import CellFloat from './CellFloat'
  import CellSelectBool from './CellSelectBool'
  import CellSelectNumber from './CellSelectNumber'
  import CellSelectText from './CellSelectText'


  export default {
    name: "table-edit-row",
    data: function () {
      let editFields = {};
      this.config.forEach(c => {
        editFields[c.field] = this.row[c.field];
      });
      if (this.row.hasOwnProperty('id')) {
        editFields.id = this.row.id;
      }
      return {
        editFields: editFields,
        btnId: uuidv4()
      }
    },

    props: {
      row: {required: true},
      config: {type: Array, required: true}
    },

    computed: {
      editDisabled: function () {
        return this.config.every(x => this.editFields[x.field] === this.row[x.field]);
      }
    },
    methods: {
      logEdit(cell) {
        this.editFields[cell.field] = cell.value;
      },
      submitEdit() {
        const payload = Object.assign({}, this.editFields);
        console.log('assigned ', payload);
        this.$emit('editRequest', payload);
      },
      submitDelete() {
        const payload = Object.assign({}, this.editFields);
        this.$emit('deleteRequest', payload);
      },
      enterEdit() {
        document.getElementById(this.btnId).focus();
      }
    },
    components: {
      CellText, CellInt, CellFloat, CellSelectBool, CellSelectNumber, CellSelectText
    },
  }
</script>

<style scoped>
  .v-btn-no-margin {
    margin: 0 !important;
  }
</style>
