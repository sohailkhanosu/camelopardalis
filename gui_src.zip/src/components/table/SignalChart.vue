<template>
  <div :id='market'></div>
</template>

<script>
  import Plotly from 'plotly.js';
  export default {
    name: "signal-chart",
    data: function () {


      return {}
    },
    computed: {},
    methods: {
      drawChart() {
        const labels = [[], [], []];
        const values = [0, 0, 0];
        const keys = Object.keys(this.signals);
        keys.forEach(k => {
          const signal = parseInt(this.signals[k]) + 1;
          labels[signal].push(k);
          values[signal] += 1;
        });

        const n = keys.length;
        const percents = values.map(x => Math.round((x / n) * 100));
        const labelStrings =  labels.map(x => x.join().toLowerCase() || "None");
        const plotData = [{
          values:percents,
          labels: labelStrings,
          text: ['bearish', 'neutral', 'bullish'],
          showlegend: false,
          hoverinfo: 'label',
          type: 'pie',
        }];

        const layout = {
          autosize: true,
          height: 300,
          width: 300,
          margin: {
            l: 20,
            r: 0,
            b: 45,
            t: 45,
            pad: 0
          }
        };
        Plotly.newPlot(this.market, plotData, layout);
      },
    },
    mounted() {
      this.drawChart();
    },
    watch: {
      signals: function(a, b) {
        this.drawChart();
      }
    },
    props: {
      market: {required: true},
      signals: {required: true}
    },
  }
</script>

<style scoped>

</style>
