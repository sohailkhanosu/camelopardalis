<template>
  <v-flex class='mx-1 elevation-6'>
    <v-card>
      <v-card-title>{{title}}
        <v-flex/>
        <slot name='menu'/>
      </v-card-title>
      <v-card-text>
        <slot name='table'/>
      </v-card-text>
    </v-card>
  </v-flex>
</template>

<script>
  export default {
    name: "table-card",
    data: function () {
      return {
        menu: false,
      }
    },
    props: {
      title: {type: String, required: true}
    },
    methods: {

    }
  }
</script>

<style lang='scss' scoped>
  .card__title {
    padding: 8px 16px 0 25px !important;
    font-weight: bold;
  }

  /*.card__text {*/
    /*padding-top: 5px !important;*/
  /*}*/
</style>
