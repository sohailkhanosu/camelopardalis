<template>
  <div>
  <power-options />
  <v-menu
    :close-on-content-click="false"
    v-model="menu"
    left
    offset-y
    transition='scale-transition'
    origin='top right'
  >
    <v-btn icon small slot="activator" >
      <v-icon color='secondary lighten-2'>settings</v-icon>
    </v-btn>
    <v-card>
      <v-list dense>
        <v-subheader>Display Filters</v-subheader>
        <v-list-tile>
          <v-list-tile-action>
            <v-switch v-model="cfg.runningToggle" :ripple='false'/>
          </v-list-tile-action>
          <v-list-tile-title>Running Bots Filter</v-list-tile-title>
        </v-list-tile>
        <v-list-group>
          <v-list-tile slot='activator'>
            <v-list-tile-action>
              <v-switch v-model="cfg.balFilterToggle" @click.stop='cfg.balFilterToggle = !cfg.balFilterToggle' :ripple='false'/>
            </v-list-tile-action>
            <v-list-tile-title>Currency Balance Filter</v-list-tile-title>
          </v-list-tile>
          <v-list-tile>
            <v-list-tile-avatar>{{cfg.balFilterQty}}</v-list-tile-avatar>
            <v-list-tile-content>
              <v-slider class='cur-slider' color='success' v-model="cfg.balFilterQty" min='0' max='200' :disabled='!cfg.balFilterToggle'/>
            </v-list-tile-content>
          </v-list-tile>
        </v-list-group>
        <v-divider/>
        <v-subheader>Settings</v-subheader>
        <v-list-tile>
          <v-list-tile-action>
            <v-switch v-model="cfg.showTotalRow" :ripple='false'/>
          </v-list-tile-action>
          <v-list-tile-title>Show Totals
          </v-list-tile-title>
        </v-list-tile>
        <v-divider/>
      </v-list>
      <v-card-actions>
        <v-spacer/>
        <v-btn flat @click="cancelMenu">Cancel</v-btn>
        <v-btn color="primary" flat @click="saveMenu">Save</v-btn>
      </v-card-actions>
    </v-card>
  </v-menu>
  </div>
</template>

<script>
  import {mapState} from 'vuex'
  import PowerOptions from '../PowerOptions';

  export default {
    name: "table-options",
    data: function () {
      return {
        menu: false,
        cfg: {},
        configKeys: new Set(['balFilterToggle', 'balFilterQty', 'exchangeFilterToggle', 'showTotalRow', 'runningToggle'])
      }
    },
    methods: {
      cancelMenu() {
        this.menu = false;
        window.setTimeout(() => this.cfg = this.updateConfig(), 200);
      },
      saveMenu() {
        this.menu = false;
        Object.keys(this.cfg).forEach(k => {
          if ((this.cfg[k] !== this.svConfig[k]) && this.configKeys.has(k)){
            this.$store.commit('svConfig', {key: k, value: this.cfg[k]})
          }
        });
      },
      updateConfig() {
        const result = {};
        Object.keys(this.svConfig).forEach(k => {
          result[k] = this.svConfig[k];
        });
        return result;
      }
    },
    computed: {
      ...mapState(['svConfig']),
    },
    mounted: function() {
      this.cfg = this.updateConfig();
    },
    components: {PowerOptions}
  }
</script>

<style lang='scss' scoped>
  .cur-slider {
    padding: 5px !important;
  }
</style>
