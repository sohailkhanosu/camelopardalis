<template>
  <div>
    <table class='table action-table'>
      <thead>
      <tr>
        <th></th>
        <th v-for="cur in supervisor_headers" @click="sortEmit(cur)" v-if='headerFilter(cur)'
            :key='cur'>{{cur}}<span v-if='svConfig.showTotalRow'><br>{{total_balance[cur] | balance}}</span>
        </th>
      </tr>
      </thead>
      <tbody>
      <tr v-for='row in actives' :key='row.exchange' v-if='rowFilter(row.exchange)'>
        <td class='power-cell'>
          <v-menu trasition='slide-x-transition' bottom right>
            <v-btn class='power-button' :ripple='false' icon small slot='activator'
                   v-show='state_syncing[row.exchange]'>
              <v-icon top small :color='handColor[bot_state[row.exchange].req]'>pan_tool</v-icon>
            </v-btn>
            <v-list>
              <v-list-tile key="send_kill" @click="requestKill(row.exchange)">
                <v-list-tile-title>Send Kill</v-list-tile-title>
              </v-list-tile>
              <v-list-tile key="manual_reset" @click="requestCancel(row.exchange)">
                <v-list-tile-title>Manual Reset</v-list-tile-title>
              </v-list-tile>
            </v-list>
          </v-menu>
          <v-btn class='power-button' :ripple='false' icon small
                 @dblclick='powerToggle(row.exchange)'
                 :loading='state_syncing[row.exchange]'
                 >
            <v-icon top small :color='radioColor[bot_state[row.exchange].bot]'>radio_button_checked</v-icon>
          </v-btn>
          {{row.exchange.substring(0, 10)}}
        </td>
        <td v-for='cur in supervisor_headers'  v-if='headerFilter(cur)' :key='cur'>{{row[cur] | balance}}</td>
      </tr>

      </tbody>
    </table>
  </div>
</template>

<script>
  import Vue from 'vue'
  import {mapState, mapGetters} from 'vuex'
  import {orderBy} from 'lodash/collection'
  import api from '../../api'

  export default {
    name: "action-table",
    data: function () {
      return {
        rateLimiter: {},
        radioColor: {
          1: 'green',
          2: 'red'
        },
        handColor: {
          1: 'warning',
          2: 'warning',
          3: 'error'
        },
        currencySort: null,
      }
    },
    props: {},
    computed: {
      ...mapState(['exchange_balance', 'bot_state', 'svConfig', 'exchangeList', 'total_balance']),
      ...mapGetters(['supervisor_headers', 'state_syncing']),
      actives() {
          return orderBy(this.exchange_balance, [x => x[this.currencySort] || 0, 'exchange'], ['desc', 'asc']);
      }
    },

    components: {},
    methods: {
      powerToggle: function (exchange) {
        if (this.rateLimiter.exchange){
          return;
        }
        this.disableButton(exchange, 1);
        if (this.state_syncing[exchange] || ((this.bot_state[exchange].req !== 2) && this.bot_state[exchange].req !== 1)) {
          console.error('illegal power request');
          return;
        }
        const toggle = 3 - this.bot_state[exchange].req;
        const payload = {ex: exchange, req: toggle};
        this.$store.commit('power_request',payload);
        api.post.power(payload);
      },

      requestKill(exchange) {
        if (this.rateLimiter.exchange){
          return;
        }
        if (this.bot_state[exchange].req !== 4) {
          const payload = {ex: exchange, req: 2};
          api.post.power(payload);
          this.$store.commit('power_request',payload);
        }
      },

      requestCancel(exchange) {
        if (this.bot_state[exchange].req !== 4) {
          this.requestKill(exchange);
        }
      },

      disableButton(exchange, seconds) {
        if (!this.rateLimiter.hasOwnProperty(exchange)) {
          Vue.set(this.rateLimiter, exchange, true);
        } else {
          this.rateLimiter[exchange] = true;
        }
        setTimeout(() => {
          this.rateLimiter[exchange] = false;
        }, seconds * 1000);
      },

      sortEmit(cur) {
        this.currencySort = this.currencySort === cur ? null : cur;
      },
      headerFilter(cur) {
        if(this.svConfig.balFilterToggle && this.total_balance.hasOwnProperty(cur)){
          return this.total_balance[cur] >= this.svConfig.balFilterQty;
        }
        return true;
      },

      rowFilter(ex) {
        const loaded = this.bot_state.hasOwnProperty(ex) && this.state_syncing.hasOwnProperty(ex);
        if (this.svConfig.runningToggle) {
          return loaded && this.bot_state[ex].bot === 1;
        }
        return loaded;
      }
    },
    filters: {
      balance: function (input) {
        if ((input === undefined) || isNaN(input)) {
          return '';
        }
        const value = parseInt(input).toString();
        switch (value.length) {
          case 0:
          case 1:
          case 2:
            const floatValue = parseFloat(input).toString();
            return floatValue.substring(0, Math.min(floatValue.length, 6));
          case 3:
            return value;
          case 4:
            return value[0] + '.' + value[1] + 'K';
          case 5:
            return value.substring(0, 2) + 'K';
          case 6:
            return value.substring(0, 3) + 'K';
          case 7:
            return value[0] + '.' + value[1] + 'M';
          case 8:
            return value.substring(0, 2) + 'M';
          case 9:
            return value.substring(0, 3) + 'M';
        }
        console.error('unexpected input/value in balance', input, value);
        return '';
      }
    }
  }
</script>

<style lang='scss' scoped>
  table.action-table {
    text-align: center !important;
    thead {
      tr {
        cursor: pointer;
        height: 38px !important;
        text-align: center;
        th {
          padding-left: 2px !important;
          padding-right: 2px !important;
        }
      }
    }
    tbody {
      tr {
        height: 35px !important;
        td {
          cursor: default;
          height: 35px !important;
          padding-left: 2px !important;
          padding-right: 2px !important;
        }
        td.power-cell {
          padding: 0 !important;
          margin: 0 !important;
          width: 110px !important;
          text-align: left !important;
          .power-button {
            margin: 0 !important;
            height: 20px !important;
            width: 20px !important;
            vertical-align: bottom;
          }
        }
      }

    }
  }

</style>
