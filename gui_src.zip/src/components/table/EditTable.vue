<template>
  <table class='table edit-table'>
    <thead>
    <table-edit-header :columns='config' @addRequest='showAddRow' @sortRequest='setColumnSort'/>
    </thead>
    <tbody>
    <table-new-row v-if='addRowVisible' :config='config' @newRequest='tableAdd' @cancelAddRequest='showAddRow'/>
    <table-edit-row v-for='row in rowSort' :key='row[keyField[0]] + row[keyField[1]]' :row='row' :config='config' @editRequest='tableEdit'
                    @deleteRequest='tableDelete'/>
    </tbody>
  </table>
</template>

<script>
  import TableEditRow from './components/TableEditRow'
  import TableEditHeader from './components/TableEditHeader'
  import TableNewRow from './components/TableNewRow'
  import api from '../../api'
  import {orderBy} from 'lodash/collection'

  export default {
    name: "edit-table",
    data: function () {
      return {
        addRowVisible: false,
        columnSort: null
      }
    },
    props: {
      config: {type: Array, required: true},
      tableId: {type: String, required: true},
      rows: {type: Array, required: true},
      keyField: {type: Array, required: true},
    },
    components: {
      TableEditRow, TableEditHeader, TableNewRow, api
    },
    computed: {
      rowSort() {
        if (this.columnSort){
          return orderBy(this.rows, [this.columnSort])
        } else {
          return this.rows;
        }
      }
    },
    methods: {
      // TODO add promise callback validation error reporting
      tableAdd(payload) {
        api[this.tableId].add(payload);
      },
      tableEdit(payload) {
        api[this.tableId].edit(payload);
      },
      tableDelete(payload) {
        api[this.tableId].remove(payload);
      },
      showAddRow(toggle) {
        this.addRowVisible = toggle;
      },
      setColumnSort(col) {
        this.columnSort = this.columnSort === col ? null : col;
      },
    }
  }
</script>

<style lang='scss'>
  table.edit-table {
    text-align: left;
    thead {
      tr {
        height: 36px !important;
      }
    }
    tbody {
      tr {
        height: 30px !important;
      }
      td {
        height: 30px !important;
      }
    }
  }

</style>
