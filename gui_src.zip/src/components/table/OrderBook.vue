<template>
  <table class='order-book table'>
    <thead>
    <tr>
      <th>Price</th>
      <th>Exchange</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for='order in combinedAsks'>
      <td :class='askStyle[order[2]]'>{{order[0] | bookEntry}}</td>
      <td :class='exchangeStyle[order[2]]'>{{order[1]}}</td>
    </tr>
    <tr class='table-rate-row grey--text'>
      <th>{{parseFloat(rate) | bookEntry}}</th>
      <th></th>
    </tr>
    <tr v-for='order in combinedBids'>
      <td :class='bidStyle[order[2]]'>{{order[0] | bookEntry}}</td>
      <td :class='exchangeStyle[order[2]]'>{{order[1]}}</td>
    </tr>
    </tbody>
  </table>
</template>

<script>

  export default {
    name: "order-book",
    data: function () {
      const emptyBook = [];
      for (let i = 0; i < 10; i++) {
        emptyBook.push(this.emptyRow);
      }
      return {
        bidStyle: ['green--text', 'primary--text text--darken-1 my-order'],
        askStyle: ['red--text', 'primary--text text--darken-1 my-order'],
        exchangeStyle: ['', 'primary--text text--darken-1 my-order'],
        emptyBook: emptyBook,
        emptyRow: ['-', '-', 0],
        rateTask: null,
      }
    },
    props: {
      book: {required: true},
      orders: {required: true},
      market: {required: true},
      rate: {requred: true}
    },
    computed: {
      combinedAsks() {
        if (!this.book || !this.book.hasOwnProperty('ask')){
          return this.emptyBook;
        }
        const combined = this.combineBook(this.book.ask);
        this.setStyle(combined, 'ask');
        while (combined.length < 10) {
          combined.unshift(this.emptyRow);
        }
        return combined;
      },
      combinedBids() {
        if (!this.book || !this.book.hasOwnProperty('bid')) {
          return this.emptyBook;
        }
        const combined = this.combineBook(this.book.bid);
        this.setStyle(combined, 'bid');
        while (combined.length < 10) {
          combined.push(this.emptyRow);
        }
        return combined;
      }
    },
    methods: {
      combineBook(book) {
        if (!book) {
          return this.emptyBook;
        }
        const keys = Object.keys(book);
        const result = [];
        let i = 0;
        while (result.length < 10 && i < 10) {
          keys.forEach(ex => {
            if (book[ex].length > i && result.length < 10) {
              result.push([book[ex][i], ex.substring(0, 10), 0])
            }
          });
          i++;
        }
        result.sort((a, b) => b[0] - a[0]);
        return result;
      },
      setStyle(rows, side) {
        if (!rows){
          return;
        }
        rows.forEach(r => {
          const ex = r[1];
          if (this.orders.hasOwnProperty(side) && this.orders[side].hasOwnProperty(ex)) {
            this.orders[side][ex].forEach(val => {
              if (r[0] === val) {
                r[2] = 1;
              }
            })
          }
        });
      }
    },
    filters: {
      bookEntry: function (input) {
        if (isNaN(input)) {
          return '-';
        }
        else if(input < 1) {
          return input.toFixed(8);
        }
        else {
          const input_str = input.toString();
          const point = input_str.indexOf('.');
          const decimals = point !== -1 ? 8 - point : 8 - input_str.length;
          return input.toFixed(decimals);
        }
      }
    }
  }
</script>

<style lang='scss' scoped>
  table.order-book {
    text-align: left;
    tr.table-rate-row {
      padding: 0 0 0 0 !important;
      margin: 0 !important;
      line-height: 1 !important;
      height: 16px !important;
      font-size: 13px !important;
      td, th {
        padding-left: 7px !important;
        padding-right: 7px !important;
        height: 16px !important;
        font-size: 13px !important;
      }
    }
    tr {
      padding: 0 0 0 0 !important;
      margin: 0 !important;
      line-height: 1 !important;
      height: 13px !important;

      td, th {
        padding-left: 7px !important;
        padding-right: 7px !important;
        height: 13px !important;

      }
    }
  }

  .my-order {
      font-weight: bold !important;
  }
</style>
