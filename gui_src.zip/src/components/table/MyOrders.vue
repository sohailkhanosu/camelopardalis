<template>
  <table class='order-book table'>
    <thead>
    <tr>
      <th>Price</th>
      <th>Exchange</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for='order in combinedAsks' class='primary--text text--darken-1'>
      <td class='red--text'>{{order ? order[0] : '-'}}</td>
      <td>{{order ? order[1]: '-'}}</td>
    </tr>
    <tr class='table-rate-row'>
      <td></td><td></td>
    </tr>
    <tr v-for='order in combinedBids' >
      <td class='green--text'>{{order ? order[0]: '-'}}</td>
      <td class='primary--text text--darken-1'>{{order ? order[1]: '-'}}</td>
    </tr>
    </tbody>
  </table>
</template>

<script>
  export default {
    name: "my-orders",
    data: function () {
      const emptyBook = [];
      for (let i = 0; i < 10; i++) {
        emptyBook.push(this.emptyRow);
      }
      return {
        bidStyle: ['green--text', 'primary--text text--darken-1'],
        askStyle: ['red--text', 'primary--text text--darken-1 my-order'],
        exchangeStyle: ['', 'primary--text text--darken-1 my-order'],
        emptyBook: emptyBook,
        emptyRow: ['-', '-']
      }
    },
    computed: {
      combinedAsks() {
        if (!this.book || !this.book.hasOwnProperty('ask')){
          return this.emptyBook;
        }
        const combined = this.combineBook(this.book.ask);
        while (combined.length < 10) {
          combined.unshift(this.emptyRow);
        }
        return combined;
      },
      combinedBids() {
        if (!this.book || !this.book.hasOwnProperty('bid')) {
          return this.emptyBook;
        }
        const combined = this.combineBook(this.book.bid);
        while (combined.length < 10) {
          combined.push(this.emptyRow);
        }
        return combined;
      }
    },
    methods: {
      combineBook(book) {
        if (!book) {
          return this.emptyBook;
        }
        const result = [];
        Object.keys(book).forEach(ex =>{
          book[ex].forEach(row => {
            result.push([row.toFixed(8), ex.substring(0,10)]);
          });
        });
        result.sort((a, b) => b[0] - a[0]);
        if (result.length > 10){
          result.splice(10);
        }
        return result;
      }
    },
    props: {
      book: {required: true},
    },
  }
</script>

<style lang='scss' scoped>
  table.order-book{
    text-align: left;
    tr.table-rate-row {
      padding: 0 0 0 0 !important;
      margin: 0 !important;
      line-height: 1 !important;
      height: 16px !important;
      font-size: 13px !important;

      td, th {
        padding-left: 7px !important;
        padding-right: 7px !important;
        height: 16px !important;
        font-size: 13px !important;

      }
    }

    tr {
      padding: 0 0 0 0 !important;
      margin: 0 !important;
      line-height: 1 !important;
      height: 13px !important;

      td, th {
        padding-left: 7px !important;
        padding-right: 7px !important;
        height: 13px !important;

      }
    }

  }
</style>
