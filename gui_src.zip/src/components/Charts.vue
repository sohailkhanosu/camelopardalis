<template>
  <v-container fluid :fullscreen='true'>
  <v-layout column :fullscreen='true'>
    <v-card dark extended>
      <v-card-actions>
        <v-subheader>{{selectedCurrency.toUpperCase()}} Markets</v-subheader><v-flex xs1 />
        <v-icon>shopping_cart</v-icon>Inventory: {{inventory}}<v-flex xs1 />
        <v-icon>shopping_cart</v-icon>Avg Cost Basis: {{acb}}<v-flex xs1 />
        <v-icon>shopping_cart</v-icon>BTC Profit: {{btcProfit}}<v-flex xs1/>
        <v-icon>shopping_cart</v-icon>USD Profit: ${{usdProfit}}<v-flex xs2 />
        <v-select
        :items="marketList"
        v-model="selectedCurrency"
        hint='Select Asset'
        persistent-hint
        autocomplete
        dense
        @input='loadCharts'
        :loading='chartLoading'
      />
      </v-card-actions>
    </v-card>
    <v-carousel :cycle='false' @input='carousel' light lazy id='chart-carousel'>
      <v-carousel-item v-for='id in plotIds' :key='id'>
        <div :id='id'></div>
      </v-carousel-item>
    </v-carousel>
  </v-layout>
  </v-container>
</template>

<script>
  import Plotly from 'plotly.js';
  import moment from 'moment';
  import debounce from 'debounce'
  import {mapState, mapGetters} from 'vuex'
  import FontAwesomeIcon from '@fortawesome/vue-fontawesome'
  import stats from '../stats'

  export default {
    name: "charts",
    data: function () {
      return {
        plots: [],
        currentPlot: 0,
        plotIds: ['bars', 'pies', 'volume', 'stats'],
        debouncedResize: debounce(this.resize, 100),
        selectedCurrency: 'usd',
        acb: 0,
        inventory: 0,
        btcProfit: 0,
        usdProfit: 0,
        chartLoading: false
      }
    },
    computed: {
      ...mapState(['rate', 'marketList', 'exchange_history', 'market_history']),
      ...mapGetters(['supervisor_headers'])
    },
    mounted () {
      this.loadCharts();
      window.addEventListener('resize', this.debouncedResize)
    },
    beforeDestroy () {
      window.removeEventListener('resize', this.debouncedResize)
    },
    components: {
      FontAwesomeIcon
    },
    methods: {
      carousel(i) {
        this.currentPlot = i;
        if (this.plots.length > i) {
          Plotly.Plots.resize(this.plots[i])
        }
      },
      loadCharts() {
        this.chartLoading = true;
        const asset = this.selectedCurrency ? this.selectedCurrency : 'usd';
        api.get.assetChart(asset)
          .then(resp => {
            const r = resp.data.data.total;
            this.acb = 0; //r.avg_inv.toFixed(7);
            this.inventory = 0; //r.inventory.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 1});
            this.btcProfit = 0; //(r.sells * r.avg_sell + r.inventory * this.rate[asset] - r.buys * r.avg_buy).toFixed(2);
            this.usdProfit = 0; //(this.rate.usd * this.btcProfit).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0});
            const charts = {
              bars: this.summaryBarCharts(resp, asset),
              pies: this.summaryPieCharts(resp, asset),
              volume: this.dailyVolumeCharts(resp, asset),
              stats: this.dailyStatsCharts(resp, asset)
            };
            this.plotIds.forEach(c => {
              Plotly.newPlot(c, charts[c][0], charts[c][1]).then(resp => this.plots.push(resp));
            });
            this.chartLoading = false;
          })
          .catch(err => {});
      },
      resize() {
        if ((this.plots.length > this.currentPlot) && (this.plots.length === this.plotIds.length) ){
          Plotly.Plots.resize(this.plots[this.currentPlot]);
        }
      },
      daySort(a, b) {
        return moment(a.day).unix() - moment(b.day).unix();
      },

      getMinMax(list, cmp) {
        if ((typeof list.length !== 'number') || (list.length === 0)) {
          return [0, 0];
        }
        let min = Number.POSITIVE_INFINITY;
        let max = Number.NEGATIVE_INFINITY;
        let i = list.length;
        while (i--) {
          min = Math.min(min, cmp(list[i]));
          max = Math.max(max, cmp(list[i]));
        }
        return [min, max];
      },

      dailyVolumeCharts(resp, asset) {
        const plotData = [];
        const r = resp.data.data;
        const trace = {};
        Object.keys(r).forEach(k => {
          if (!trace.hasOwnProperty(k)) {
            if ((Object.keys(r[k].vol_by_day).length < 2) || (k.indexOf(asset) !== -1) || (k === 'total')) {
              return;
            }
            trace[k] = []
          }
          const volume = r[k].vol_by_day;
          Object.keys(volume).forEach(day => {
            trace[k].push({day: day, volume: volume[day]});
          });
        });
        Object.keys(trace).forEach(title => {
          trace[title].sort(this.daySort);
          const traceData = {name: title.substring(0, 8), x: [], y: [], type: 'bar'};
          trace[title].forEach(point => {
            traceData.x.push(point.day);
            traceData.y.push(point.volume);
          });
          plotData.push(traceData);
        });

        const layout = {
          legend: {x: 0.95, y: 1},
          title: asset.toUpperCase() + ' Daily Volume',
          height: 1000,
          barmode: 'stack'
        };

        return [plotData, layout];
      },

      dailyStatsCharts(resp, asset) {
        const plotData = [];
        const r = resp.data.data;
        const volume = [];
        const price = [];
        Object.keys(r).forEach(k => {
          if (k.substring(0, 2) !== '20') {
            return;
          }
          volume.push({day: k, buy: r[k].buys, sell: r[k].sells});
          price.push({day: k, buy: r[k].avg_buy, sell: r[k].avg_sell})
        });
        volume.sort(this.daySort);
        price.sort(this.daySort);
        const volumeTrace = {name: 'Volume', x: [], y: [], type: 'scatter', yaxis: 'y2', line: {width: 1}};
        const priceTraceBuys = {name: 'Buy Price', x: [], y: [], type: 'scatter', mode: 'markers'};
        const priceTraceSells = {name: 'Sell Price', x: [], y: [], type: 'scatter', mode: 'markers'};
        volume.forEach(r => {
          volumeTrace.x.push(r.day);
          volumeTrace.y.push(r.buy + r.sell);
        });
        price.forEach(r => {
          priceTraceBuys.x.push(r.day);
          priceTraceSells.x.push(r.day);
          priceTraceBuys.y.push(r.buy);
          priceTraceSells.y.push(r.sell);
        });

        plotData.push(priceTraceBuys, priceTraceSells, volumeTrace);

        const layout = {
          legend: {x: 0.95, y: 1},
          title: asset.toUpperCase() + ' Daily Stats',
          height: 1000,
          yaxis: {
            side: 'left'
          },
          yaxis2: {
            overlaying: 'y',
            side: 'right'
          }
        };

        return [plotData, layout];
      },

      summaryPieCharts(resp, asset) {
        const plotData = [];
        const r = resp.data.data;
        const exchangeVals = [];
        const exchangeLabels = [];
        const marketVals = [];
        const marketLabels = [];
        Object.keys(r).forEach(k => {
          if (k.indexOf(asset) !== -1) {
            marketVals.push(r[k].buys + r[k].sells);
            marketLabels.push(k);
          }
          else if ((k.substring(0, 2) !== '20') && (k !== 'total')) {
            exchangeVals.push(r[k].buys + r[k].sells);
            exchangeLabels.push(k.substring(0, 8));
          }
        });

        plotData.push({
          values: exchangeVals,
          labels: exchangeLabels,
          domain: {
            x: [0, .48],
          },
          name: 'Exchange Volume',
          hoverinfo: 'label+percent+name',
          type: 'pie'
        }, {
          values: marketVals,
          labels: marketLabels,
          domain: {
            x: [.52, 1],
          },
          name: 'Market Volume',
          hoverinfo: 'label+percent+name',
          type: 'pie'
        });

        const layout = {
          title: asset.toUpperCase() + ' Volume Distribution',
          height: 1000,
          autosize: true,
        };
        return [plotData, layout];
      },

      summaryBarCharts(asset) {
        const plotData = [];
        const r = resp.data.data.total;
        const dayKeys = Object.keys(r.vol_by_day);
        if (dayKeys.length < 0) {
          console.error('empty data set in summary bar charts');
          return null;
        }


        const range = this.getMinMax(dayKeys, x => moment(x, 'YYYY-MM-DD').unix());
        const trading_days = Math.floor((range[1] - range[0]) / 86400);
        const filteredAvg = Math.round((r.buys + r.sells) / dayKeys.length);

        plotData.push(
          {
            x: [filteredAvg],
            y: ['Daily Vol'],
            type: 'bar',
            name: dayKeys.length + ' active days',
            orientation: 'h',
            hoverinfo: 'name',
            marker: {
              opacity: 0.6,
              line: {
                color: 'rbg(8,48,107)',
                width: 1
              }
            },
            text: filteredAvg,
            textposition: 'outside',
          },
          {
            x: [Math.round(r.daily_avg)],
            y: ['Daily Vol'],
            type: 'bar',
            name: trading_days + ' trading days',
            orientation: 'h',
            hoverinfo: 'name',
            marker: {
              opacity: 0.6,
              line: {
                color: 'rbg(8,48,107)',
                width: 1
              }
            },
            text: Math.round(r.daily_avg),
            textposition: 'outside',
          }
        );

        const price_range = [r.avg_buy * 0.85, r.avg_buy * 1.15];
        plotData.push(
          {
            x: [r.avg_buy.toFixed(8)],
            y: ['Price'],
            type: 'bar',
            name: 'Buys',
            orientation: 'h',
            hoverinfo: 'name',
            marker: {
              line: {
                color: 'rbg(8,48,107)',
                width: 1
              }
            },
            text: [r.avg_buy.toFixed(8)],
            textposition: 'outside',
            xaxis: 'x2'
          },
          {
            x: [r.avg_sell.toFixed(8)],
            y: ['Price'],
            type: 'bar',
            name: 'Sells',
            orientation: 'h',
            hoverinfo: 'name',
            marker: {
              opacity: 0.6,
              line: {
                color: 'rbg(8,48,107)',
                width: 1
              }
            },
            text: [r.avg_sell.toFixed(8)],
            textposition: 'outside',
            xaxis: 'x2'
          },
        );

        const layout = {
          barmode: 'group',
          showlegend: false,
          height: 1000,
          autosize: true,
          title: asset.toUpperCase() + ': Summary',
          textfont: {
            family: 'Roboto'
          },
          xaxis: {
            visible: false,
          },
          xaxis2: {
            visible: false,
            overlaying: 'x',
            range: price_range
          },
          yaxis: {
            tickangle: -90,
            titlefont: {
              size: 16
            },
          }
        };
        return [plotData, layout]
      }
    }
  }


</script>


<style scoped>
  #chart-carousel {
    height: 1030px;
  }
</style>
