<template>
  <v-app>
    <div id="app">
      <v-navigation-drawer
        clipped
        fixed
        v-model="drawer"
        app
        mini-variant
      >
        <v-list dense>
          <v-list-tile :to='{name: "supervisor"}'>
            <v-list-tile-action>
              <v-icon>visibility</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
              <v-list-tile-title>Currency</v-list-tile-title>
            </v-list-tile-content>
          </v-list-tile>
          <v-list-tile :to='{name: "orderbook"}'>
            <v-list-tile-action>
              <v-icon>subscriptions</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
              <v-list-tile-title>Orderbook</v-list-tile-title>
            </v-list-tile-content>
          </v-list-tile>
          <v-list-tile :to='{name: "records"}'>
            <v-list-tile-action>
              <v-icon>reorder</v-icon>
            </v-list-tile-action>
            <v-list-tile-content>
              <v-list-tile-title>Records</v-list-tile-title>
            </v-list-tile-content>
          </v-list-tile>
        </v-list>
      </v-navigation-drawer>
      <v-toolbar app fixed clipped-left dense>
        <v-toolbar-side-icon @click.stop="drawer = !drawer"/>
        <v-toolbar-title>Crypty Bot </v-toolbar-title>
        <v-subheader class='mx-4 px-4'><balance-display /></v-subheader>
      </v-toolbar>
      <v-content>
        <v-fade-transition mode="out-in">
          <router-view/>
        </v-fade-transition>
      </v-content>
      <v-footer app fixed>
        <span>&copy; 2018</span>
      </v-footer>
    </div>
  </v-app>
</template>

<script>
  // import TableOptions from './table/TableOptions'
  // import PowerOptions from './PowerOptions'
  import BalanceDisplay from './BalanceDisplay'
  import api from "../api"

  export default {
    name: "app",
    data: () => ({
      drawer: true
    }),
    components: {
      BalanceDisplay
    },
    mounted: function () {
      setInterval(function () {
        const store = this.$store;
        api.get.polling()
          .then(response => {
            try {
              const side = {sell: 'ask', buy: 'bid'};
              const state = {
                exchange_balance: {},
                exchange_trades: {},
                market_trades: {},
                positions: {},
                signal: {}
              };
              const total_balance = {};
              Object.keys(response.data.data).forEach(ex => {
                const update = response.data.data[ex];
                store.commit('update_bot_state', {ex: ex, bot: update.running});
                state.exchange_balance[ex] = {};
                state.exchange_trades[ex] = [];
                Object.keys(update.balances).forEach(cur => {
                  const c = cur.toLowerCase();
                  const qty = update.balances[cur].available + update.balances[cur].reserved;
                  if(qty > 0) {
                    const current_total = total_balance.hasOwnProperty(c) ? total_balance[c] : 0;
                    total_balance[c] = current_total + qty;
                    state.exchange_balance[ex][c] = qty;
                  }
                });
                const live = {source: ex, book: {}, orders: {}};
                update.activeOrders.forEach(o => {
                  const m = o.market.toLowerCase();
                  if (!live.orders.hasOwnProperty(m)) {
                    live.orders[m] = {bid: [], ask: []}
                  }
                  live.orders[m][side[o.side]].push(o.rate);
                });
                Object.keys(update.orderBooks).forEach(m => {
                  live.book[m.toLowerCase()] = {
                    bid: update.orderBooks[m].bids.map(x => x.rate),
                    ask: update.orderBooks[m].asks.map(x => x.rate),
                  }
                });
                store.commit('live_orders', live);
                Object.keys(update.trades).forEach(market => {
                  const m = market.toLowerCase();
                  if (!state.market_trades.hasOwnProperty(m)) {
                    state.market_trades[m] = [];
                  }
                  update.trades[market].forEach(t => {
                    state.exchange_trades[ex].push({s_id: ex, ...t});
                    state.market_trades[m].push({s_id: ex, ...t});
                  })
                });
                Object.keys(update.positions).forEach(market => {
                  state.positions[market.toLowerCase()] = update.positions[market]
                });
                Object.keys(update.signals).forEach(market => {
                  state.signal[market.toLowerCase()] = update.signals[market];
                });
              });
              store.commit('exchange_balance', state.exchange_balance);
              store.commit('history', {ex: state.exchange_trades, m: state.market_trades});
              store.commit('positions', state.positions);
              store.commit('signal', state.signal);
              store.commit('total_balance', total_balance);
            }
            catch (error) {
              console.error(error);
            }
          }).catch(err => {console.error(err)});
      }.bind(this), 2000);
    }
  }
</script>

<style scoped>
</style>
