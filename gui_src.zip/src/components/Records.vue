<template>
      <v-container fluid>
        <v-card>
          <v-card-title>
            <v-layout row wrap justify-space-between>
              <v-flex xs12 sm6 md3 lg1>
                <v-menu
                  ref="start_menu"
                  lazy
                  :close-on-content-click="false"
                  v-model="start_menu"
                  offset-y
                  :nudge-right="40"
                  transition="scale-transition"
                >
                  <v-text-field
                    slot="activator"
                    label="Start Date"
                    v-model="start_date"
                    prepend-icon="event"
                    readonly
                  />
                  <v-date-picker v-model="start_date" :allowed-dates='allowedStarts' no-title scrollable>
                    <v-spacer/>
                    <v-btn flat color="primary" @click="cancelDateRequest('start')">Cancel</v-btn>
                    <v-btn flat color="primary" @click="startFilterRequest(start_date)">OK</v-btn>
                  </v-date-picker>
                </v-menu>
              </v-flex>
              <v-flex xs12 sm6 md3 lg1>
                <v-menu
                  ref="end_menu"
                  lazy
                  :close-on-content-click="false"
                  v-model="end_menu"
                  transition="scale-transition"
                  offset-y
                  :nudge-right="40"
                >
                  <v-text-field
                    slot="activator"
                    label="End Date"
                    v-model="end_date"
                    prepend-icon="event"
                    readonly
                  />
                  <v-date-picker v-model="end_date" :allowed-dates='allowedEnds' no-title scrollable>
                    <v-spacer/>
                    <v-btn flat color="primary" @click="cancelDateRequest('end')">Cancel</v-btn>
                    <v-btn flat color="primary" @click="endFilterRequest(end_date)">OK</v-btn>
                  </v-date-picker>
                </v-menu>
              </v-flex>
              <v-flex xs12 md5 lg3>
                <v-select
                  :items="marketList"
                  v-model="selectedCurrency"
                  hint="Select Market"
                  persistent-hint
                  autocomplete
                  dense
                  @input='loadCurrencyTradesRecords'
                />
              </v-flex>
              <v-flex xs12 md5 lg3>
                <v-select
                  :items="exchangeList"
                  v-model="selectedExchange"
                  hint="Select Exchange"
                  persistent-hint
                  autocomplete
                  dense
                  @input='loadExchangeTradesRecords'
                />
              </v-flex>
              <v-flex xs12 md6 lg3>
                <v-text-field
                  append-icon="search"
                  label="Filter Results"
                  single-line
                  hide-details
                  v-model="keyword_filter"
                />
              </v-flex>
            </v-layout>
          </v-card-title>
          <v-card-text>
            <v-data-table
              :headers="tradesHeaders"
              :items="rows"
              :search="keyword_filter"
              :loading='loading'
              disable-initial-sort
              :rows-per-page-items='[15,50,100,{"text":"All","value":-1}]'
            >
              <template slot="items" slot-scope="props">
                <td class="text-xs-left">{{ props.item.s_id }}</td>
                <td class="text-xs-left">{{ props.item.market.toLowerCase() }}</td>
                <td class="text-xs-left">{{ props.item.rate }}</td>
                <td class="text-xs-left">{{ props.item.quantity }}</td>
                <td class="text-xs-left">{{ props.item.side }}</td>
                <td class="text-xs-left">{{ props.item.time | dateStr}}</td>
                <td class="text-xs-left">{{ props.item.order_id }}</td>
              </template>

              <v-alert slot="no-results" :value="true" color="error" icon="warning">
                Your search found no results.
              </v-alert>
            </v-data-table>
          </v-card-text>
        </v-card>
      </v-container>
</template>

<script>
  import moment from 'moment'
  import {mapState} from 'vuex'
  import {orderBy} from 'lodash/collection'
  export default {
    name: "records",
    data: function () {
      return {
        search: '',
        start_date: null,
        start_menu: false,
        end_date: null,
        end_menu: false,
        loading: false,
        selectedCurrency: null,
        selectedExchange: null,
        keyword_filter: null,
        tradesHeaders: [
          {text: 'Exchange', align: 'left', sortable: false, value: 's_id'},
          {text: 'Market', sortable: false, value: 'market'},
          {text: 'Rate', sortable: false, value: 'rate'},
          {text: 'Qty', sortable: false, value: 'quantity'},
          {text: 'Side', sortable: false, value: 'side'},
          {text: 'Date', sortable: false, value: 'time'},
          {text: 'Trade Id', sortable: false, value: 'order_id'}
        ],
        rows: [],
      }
    },
    computed: {
      ...mapState(['marketList', 'exchangeList', 'market_history', 'exchange_history']),
    },
    methods: {
      allowedStarts(x) {
        return this.end_date ? moment(x, 'YYYY-MM-DD').isSameOrBefore(moment(this.end_date, 'YYYY-MM-DD')) : true;
      },
      allowedEnds(x) {
        return this.start_date ? moment(x, 'YYYY-MM-DD').isSameOrAfter(moment(this.start_date, 'YYYY-MM-DD')) : true;
      },
      loadCurrencyTradesRecords(cur) {
        this.selectedExchange = null;
        const rows = this.market_history.hasOwnProperty(cur) ? this.market_history[cur].filter(this.dateRangeFilter) : [];
        this.rows = orderBy(rows, [x => parseInt(x.time)], ['desc']);
      },
      loadExchangeTradesRecords(ex) {
        this.selectedCurrency = null;
        const rows = this.exchange_history.hasOwnProperty(ex) ? this.exchange_history[ex].filter(this.dateRangeFilter) : [];
        this.rows = orderBy(rows, [x => parseInt(x.time)], ['desc']);
      },
      dateRangeFilter(x) {
        const day = moment(moment.unix(x.time).format('YYYY-MM-DD'), 'YYYY-MM-DD');
        const start = this.start_date ? day.isSameOrAfter(moment(this.start_date, 'YYYY-MM-DD')) : true;
        const end = this.end_date ? day.isSameOrBefore(moment(this.end_date, 'YYYY-MM-DD')) : true;
        return start && end;
      },
      startFilterRequest(date) {
        this.start_date = date;
        this.start_menu = false;
        this.resetRows();
      },
      endFilterRequest(date) {
        this.end_date = date;
        this.end_menu = false;
        this.resetRows();
      },
      cancelDateRequest(type) {
        if (type === 'start') {
          this.start_date = null;
          this.start_menu = false;
        } else {
          this.end_date = null;
          this.end_menu = false;
        }
        this.resetRows();
      },
      resetRows(){
        if (this.selectedExchange) {
          this.loadExchangeTradesRecords(this.selectedExchange);
        } else if (this.selectedCurrency) {
          this.loadCurrencyTradesRecords(this.selectedCurrency);
        }
      }
    },
    filters: {
      dateStr(input) {
        return moment.unix(parseInt(input)).format('lll')
      }
    }
  }
</script>

<style scoped>

</style>
