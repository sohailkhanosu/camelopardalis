<template>
  <span>
    <font-awesome-icon :icon="btcIcon"/>
    {{ computedBtc.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 6}) }}
    <font-awesome-icon :icon="dollarIcon" class='ml-4'/>
    {{ computedUSD.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 2}) }}
  </span>
</template>

<script>
  import faBtc from '@fortawesome/fontawesome-free-brands/faBtc';
  import faDollarSign from '@fortawesome/fontawesome-free-solid/faDollarSign'
  import FontAwesomeIcon from '@fortawesome/vue-fontawesome'
  import {mapState} from 'vuex'

  export default {
    name: "balance-display",
    computed: {
      ...mapState(['total_balance', 'rate']),
      btcIcon() {
        return faBtc
      },
      dollarIcon() {
        return faDollarSign
      },
      computedBtc() {
        let total = 0;
        Object.keys(this.total_balance).forEach(c => {
          total += this.total_balance[c] * this.rate[c] || 0;
        });
        return total
      },
      computedUSD() {
        let total = 0;
        Object.keys(this.total_balance).forEach(c => {
          total += this.total_balance[c] * this.rate[c] || 0;
        });
        return total * this.rate['usd'];
      }
    },
    components: {
      FontAwesomeIcon
    }
  }
</script>

<style scoped>

</style>
