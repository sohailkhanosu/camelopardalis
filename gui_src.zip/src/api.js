import config from './config'
import axios from 'axios'


export default {
  get: {
    rate: () => {
      return axios.get('https://api.coinmarketcap.com/v1/ticker/?limit=100');
    },
    state: () => {
      return axios.get(config.node + 'state');
    },
    polling: () => {
      return axios({method: 'get', url: config.node + 'state', timeout: 5000})
    }
  },
  post: {
    power: (payload) => {
      return axios.post(config.node + 'state', {'data': {[payload.ex]: payload.req === 1}})
        .catch(err => {console.error(err)});
    }
  }
}
