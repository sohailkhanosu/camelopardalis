import axios from 'axios'
import api from '../api'
import config from '../config'

export default [
  async store => {
    try {
      const response = await api.get.rate();
      const payload = {};
      response.data.forEach(c => {
        if (payload.hasOwnProperty(c.symbol.toLowerCase())){
          return;
        }
        payload[c.symbol.toLowerCase()] = c.price_btc ? c.price_btc : 0;
      });
      payload['usd'] = response.data[0].price_usd;
      payload['jpy'] = payload['usd'] * 106;
      store.commit('rates', payload);
    } catch (error) {
      console.error(error);
    }
  },
  async store => {
    try {
      const response = await api.get.state();
      const side = {sell: 'ask', buy: 'bid'};
      const state = {
        bot_state: {},
        exchange_balance: {},
        exchange_trades: {},
        market_trades: {},
        positions: {},
        signal: {}
      };
      const total_balance = {};
      Object.keys(response.data.data).forEach(ex => {
        const update = response.data.data[ex];
        state.bot_state[ex] = update.running;
        state.exchange_balance[ex] = {};
        state.exchange_trades[ex] = [];
        Object.keys(update.balances).forEach(cur => {
          const c = cur.toLowerCase();
          const qty = update.balances[cur].available + update.balances[cur].reserved;
          if (qty > 0) {
            const current_total = total_balance.hasOwnProperty(c) ? total_balance[c] : 0;
            total_balance[c] = current_total + qty;
            state.exchange_balance[ex][c] = qty;
          }
        });
        const live = {source: ex, book: {}, orders: {}};
        update.activeOrders.forEach(o => {
          const m = o.market.toLowerCase();
          if(!live.orders.hasOwnProperty(m)){
            live.orders[m] = {bid: [], ask: []}
          }
          live.orders[m][side[o.side]].push(o.rate);
        });
        Object.keys(update.orderBooks).forEach(m => {
          live.book[m.toLowerCase()] = {
            bid: update.orderBooks[m].bids.map(x => x.rate),
            ask: update.orderBooks[m].asks.map(x => x.rate),
          }
        });
        store.commit('live_orders', live);
        Object.keys(update.trades).forEach(market => {
          const m = market.toLowerCase();
          if(!state.market_trades.hasOwnProperty(m)) {
            state.market_trades[m] = [];
          }
          update.trades[market].forEach(t => {
            state.exchange_trades[ex].push({s_id: ex, ...t});
            state.market_trades[m].push({s_id: ex, ...t});
          })
        });
        Object.keys(update.positions).forEach(market => {
          state.positions[market.toLowerCase()] = update.positions[market]
        });
        Object.keys(update.signals).forEach(market => {
          state.signal[market.toLowerCase()] = update.signals[market];
        });
      });
      store.commit('init_bot_state', state.bot_state);
      store.commit('exchange_balance', state.exchange_balance);
      store.commit('history', {ex: state.exchange_trades, m: state.market_trades});
      store.commit('positions', state.positions);
      store.commit('signal', state.signal);
      store.commit('total_balance', total_balance);
    } catch (error) {
      console.error(error);
    }
  },
]
