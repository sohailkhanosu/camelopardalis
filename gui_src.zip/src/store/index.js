import Vue from 'vue'
import Vuex from 'vuex'
import 'babel-polyfill'
import plugins from './plugins'
import config from '../config'
Vue.use(Vuex);

function flatten(payload, root, child) {
  let result = [];
  Object.keys(payload).sort().forEach(r => {
    Object.keys(payload[r]).sort().forEach(c => {
      result.push({[root]: r, [child]: c, ...payload[r][c]})
    })
  });
  return result;
}

export default new Vuex.Store({
  state: {
    currencyList: ['jpy',  'btc', 'etc', 'eth', 'ltc', ],
    exchangeSet: new Set(['bitmex', 'hitbtc']),
    exchangeList: ['bitmex', 'hitbtc'],
    marketList: ['etc_btc', 'eth_btc', 'ltc_btc', 'jpy_btc', 'usd_btc',],
    exchange_balance: [],
    exchange_history: {},
    market_history: {},
    bot_state: {},
    positions: {},
    signal: {},
    rate: {},
    exchange_orders: {},
    market_orders: {},
    exchange_books: {},
    market_books: {},
    live_markets: [],
    heartbeat: {},
    total_balance: {},
    svConfig: {
      currencySort: null,
      runningToggle: false,
      balFilterToggle: false,
      balFilterQty: 2,
      activeBotFilter: false,
      showTotalRow: false,
    },
  },
  getters: {
    supervisor_headers: state => {
      let result = [];
      let found = {};

      state.exchange_balance.forEach(b => {
        Object.keys(b).forEach(cur => {
          if ((cur === 'exchange') || found[cur]) {
            return;
          }
          found[cur] = true;
          result.push(cur)
        });
      });
      return result.sort();
    },
    state_syncing: state => {
      let result = {};
      Object.entries(state.bot_state).forEach(kv => {
        result[kv[0]] = (kv[1].bot !== kv[1].req);
      });
      return result;
    },
  },
  mutations: {
    init_bot_state(state, payload) {
      const updated_state = {};
      Object.keys(payload).forEach(ex => {
        const runState = payload[ex] ? 1 : 2;
        updated_state[ex] = {bot: runState, req: runState};
      });
      state.bot_state = updated_state;
    },
    update_bot_state(state, payload) {
      Vue.set(state.bot_state, payload.ex, {bot: payload.bot ? 1 : 2, req: state.bot_state[payload.ex].req})
    },
    power_request(state, payload) {
      console.log(payload);
      Vue.set(state.bot_state, payload.ex, {bot: state.bot_state[payload.ex].bot, req: payload.req})
    },
    exchange_balance(state, payload) {
      state.exchange_balance = Object.keys(payload).sort().map(x => ({exchange: x, ...payload[x]}));
    },
    exchange_config(state, payload) {
      const keys = Object.keys(payload).sort();
      state.exchangeConfigDict = payload;
      state.exchangeSet = new Set(keys);
      state.exchange_config = keys.map(x => ({exchange: x, ...payload[x]}));
      state.exchangeList = keys;
    },
    rates(state, payload) {
      state.rate = payload;
    },
    live_orders(state, payload) {
      const markets = {};
      const cutoff = Date.now() - 60000;
      const result = {
        exchange_books: {},
        exchange_orders: {}
      };
      state.heartbeat[payload.source] = Date.now();
      state.exchange_orders[payload.source] = payload.orders;
      state.exchange_books[payload.source] = payload.book;
      ['exchange_orders', 'exchange_books'].forEach(field => {
        Object.keys(state[field]).forEach(ex => {
          if (state.heartbeat[ex] < cutoff) {
            state[field][ex] = {};
            return;
          }
          Object.keys(state[field][ex]).forEach(m => {
            markets[m] = true;
            if (!result[field].hasOwnProperty(m)) {
              result[field][m] = {bid: {}, ask: {}};
            }
            result[field][m]['bid'][ex] = state[field][ex][m].bid;
            result[field][m]['ask'][ex] = state[field][ex][m].ask;
          })
        });
      });
      state.live_markets = Object.keys(markets).sort();
      state.market_orders = result.exchange_orders;
      state.market_books = result.exchange_books;
    },
    svConfig(state, payload) {
      state.svConfig[payload.key] = payload.value;
    },
    total_balance(state, payload) {
      state.total_balance = payload;
    },
    signal(state, payload) {
      state.signal = payload;
    },
    positions(state, payload) {
      state.positions = payload;
    },
    history(state, payload) {
      state.market_history = payload.m || {};
      state.exchange_history = payload.ex || {};
    }
  },
  actions: {},
  modules: {},
  plugins: plugins
})

