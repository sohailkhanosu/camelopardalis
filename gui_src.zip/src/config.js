export default{
  node: '/',
}
