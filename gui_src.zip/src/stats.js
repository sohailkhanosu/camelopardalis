class Stats {
  constructor() {
    this.buy_amt = 0;
    this.sell_amt = 0;
    this.buy_cost = 0;
    this.sell_cost = 0;
    this.start_ts = Infinity;
    this.end_ts = 0;
    this.dayVolume = {};
  }

  static dayString(unixTs) {
    return (moment.unix(unixTs).format('YYYY-MM-DD'));
  }

  static minuteTimestamp(unixTs, convert) {
    let result = parseInt(unixTs / 60) * 60;
    while ((result > 1493596860) && (!convert.hasOwnProperty(result))) {
      result -= 60;
    }
    return convert[result];
  }

  addRow(r, converter=null) {
    const buy = r.buy_cur === r.market.split('_')[0];
    const volume = buy ? r.buy_amt : r.sell_amt;
    if (buy) {
      this.buy_amt += volume;
      this.buy_cost += converter ? Stats.minuteTimestamp(r.date, converter) * r.sell_amt : r.sell_amt;
    } else {
      this.sell_amt += volume;
      this.sell_cost += converter ? Stats.minuteTimestamp(r.date, converter) * r.buy_amt : r.buy_amt;
    }
    this.addDailyVolume(r.date, volume);
    this.start_ts = Math.min(r.date, this.start_ts);
    this.end_ts = Math.max(r.date, this.end_ts);
  }

  calculateStats() {
    return {
      buys: this.buy_amt,
      avg_buy: this.buy_amt > 0 ? this.buy_cost / this.buy_amt : 0,
      sells: this.sell_amt,
      avg_sell: this.sell_amt > 0 ? this.sell_cost / this.sell_amt : 0,
      inventory: this.buy_amt - this.sell_amt,
      avg_inv: Math.abs(this.buy_amt - this.sell_amt) > 0.1 ? (this.buy_cost - this.sell_cost) / (this.buy_amt - this.sell_amt) : 0,
      daily_avg: this.start_ts < this.end_ts ? ((this.buy_amt + this.sell_amt) / (this.end_ts - this.start_ts)) * 86400 : 0,
      vol_by_day: this.dayVolume
    }
  }

  addDailyVolume(ts, qty) {
    const day = Stats.dayString(ts);
    if (!this.dayVolume.hasOwnProperty(day)) {
      this.dayVolume[day] = 0;
    }
    this.dayVolume[day] += qty;
  }
}

export default {
  Stats
}
